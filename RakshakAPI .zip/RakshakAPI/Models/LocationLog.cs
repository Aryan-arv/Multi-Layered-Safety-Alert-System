﻿//namespace RakshakAPI.Models
//{
//    public class LocationLog
//    {
//    }
//}


using System;
using System.ComponentModel.DataAnnotations;

namespace RakshakAPI.Models
{
    public class LocationLog
    {
        [Key]
        public int Id { get; set; }

        public string? Username { get; set; }


        [Required]
        public double Latitude { get; set; }

        [Required]
        public double Longitude { get; set; }

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string Message { get; set; } = string.Empty;
    }
}
