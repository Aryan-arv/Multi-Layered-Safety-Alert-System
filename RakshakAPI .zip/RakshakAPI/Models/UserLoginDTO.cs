﻿//namespace RakshakAPI.Models
//{
//    public class UserLoginDTO
//    {
//    }
//}

namespace RakshakAPI.Models
{
    public class UserLoginDTO
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
