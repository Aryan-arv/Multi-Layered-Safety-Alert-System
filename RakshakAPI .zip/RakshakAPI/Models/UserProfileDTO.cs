﻿//namespace RakshakAPI.Models
//{
//    public class UserProfileDTO
//    {
//    }
//}



namespace RakshakAPI.Models
{
    public class UserProfileDTO
    {
        public int Id { get; set; }
        public string? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? PinCode { get; set; }
        public string? ParentName { get; set; }
        public string? ParentContact { get; set; }
    }
}
