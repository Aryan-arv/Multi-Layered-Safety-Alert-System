﻿//namespace RakshakAPI.Models
//{
//    public class CrimeReportDTO
//    {
//    }
//}

namespace RakshakAPI.Models
{
    public class CrimeReportDTO
    {
        public int IncidentId { get; set; }
        public string Area { get; set; }
        public string Region { get; set; }
        public string CrimeType { get; set; }
        public string Gender { get; set; }
        public DateTime CrimeDate { get; set; }
        public TimeSpan ReportedTime { get; set; }
        public float Latitude { get; set; }
        public float Longitude { get; set; }
        public string Source { get; set; }
        public int AgeOfVictim { get; set; }
        public string? Messages { get; set; }
    }
}
