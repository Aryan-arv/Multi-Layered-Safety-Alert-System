﻿//namespace RakshakAPI.Models
//{
//    public class CrimeReport
//    {
//        public int IncidentId { get; set; }
//        public string? Area { get; set; }
//        public string? Region { get; set; }
//        public string? CrimeType { get; set; }
//        public string? Gender { get; set; }
//        public DateTime CrimeDate { get; set; }
//        public TimeSpan ReportedTime { get; set; }
//        public float Latitude { get; set; }
//        public float Longitude { get; set; }
//        public string? Source { get; set; }
//        public int? AgeOfVictim { get; set; }
//        public string? Messages { get; set; }
//    }
//}

using System.ComponentModel.DataAnnotations;

namespace RakshakAPI.Models
{
    public class CrimeReport
    {
        public int IncidentId { get; set; }

        [Required]
        [StringLength(255)]
        public string Area { get; set; }

        [Required]
        [StringLength(255)]
        public string Region { get; set; }

        [Required]
        [StringLength(100)]
        public string CrimeType { get; set; }

        [Required]
        [StringLength(10)]
        public string Gender { get; set; }

        [Required]
        public DateTime CrimeDate { get; set; }

        [Required]
        public TimeSpan ReportedTime { get; set; }

        public float Latitude { get; set; }

        public float Longitude { get; set; }

        [Required]
        [StringLength(255)]
        public string Source { get; set; }

        [Range(1, 150)]
        public int AgeOfVictim { get; set; }

        [StringLength(500)]
        public string? Messages { get; set; }
    }
}
