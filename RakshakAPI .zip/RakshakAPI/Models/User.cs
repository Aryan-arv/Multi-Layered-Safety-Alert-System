﻿//namespace RakshakAPI.Models
//{
//    public class User
//    {
//    }
//}


//using System.ComponentModel.DataAnnotations;

//namespace RakshakAPI.Models
//{
//    public class User
//    {
//        [Key]
//        public int Id { get; set; }

//        [Required]
//        public string Username { get; set; }

//        [Required]
//        public string Password { get; set; }
//    }
//}
//using System.ComponentModel.DataAnnotations;

//namespace RakshakAPI.Models
//{
//    public class User
//    {
//        [Key]
//        public int Id { get; set; }

//        [Required]
//        public string Username { get; set; }

//        [Required]
//        public string Password { get; set; }

//        public string? Gender { get; set; }
//        public DateTime? DateOfBirth { get; set; }

//        public string? AddressLine1 { get; set; }
//        public string? AddressLine2 { get; set; }

//        public string? PinCode { get; set; }

//        public string? ParentName { get; set; }
//        public string? ParentContact { get; set; }
//    }
//}
using System.ComponentModel.DataAnnotations;

namespace RakshakAPI.Models
{
    public class User
    {
        //[Key]
        //public int Id { get; set; }

        //[Required]
        //public string Username { get; set; }

        //[Required]
        //public string Password { get; set; }

        //public string? Gender { get; set; }
        //public DateTime? DateOfBirth { get; set; }

        //public string? AddressLine1 { get; set; }
        //public string? AddressLine2 { get; set; }

        //public string? PinCode { get; set; }

        //public string? ParentName { get; set; }
        //public string? ParentContact { get; set; }
        [Key]
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        // ✅ These will be ignored during update, but required for login/register only
        public string? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }

        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }

        public string? PinCode { get; set; }

        public string? ParentName { get; set; }
        public string? ParentContact { get; set; }

    }
}
