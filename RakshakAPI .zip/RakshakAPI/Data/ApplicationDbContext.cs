﻿//using Microsoft.EntityFrameworkCore;
//using RakshakAPI.Models;
//using System.Collections.Generic;

//namespace RakshakAPI.Data
//{
//    public class ApplicationDbContext : DbContext
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

//        public DbSet<CrimeReport> CrimeReports { get; set; }
//    }
//}
using Microsoft.EntityFrameworkCore;
using RakshakAPI.Models;

namespace RakshakAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<CrimeReport> CrimeReports { get; set; }
        public DbSet<LocationLog> LocationLogs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CrimeReport>()
                .HasKey(c => c.IncidentId); // 👈 Telling EF that IncidentId is Primary Key
        }
    }
}
