﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;

namespace RakshakAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MLPredictionController : ControllerBase
    {
        private readonly HttpClient _httpClient;

        public MLPredictionController()
        {
            _httpClient = new HttpClient();
        }

        [HttpPost("predict")]
        public async Task<IActionResult> PredictRisk([FromBody] object inputJson)
        {
            // Flask API endpoint
            var flaskUrl = "http://127.0.0.1:5000/predict";

            // Convert the incoming C# object to JSON and send to Flask
            var content = new StringContent(inputJson.ToString(), Encoding.UTF8, "application/json");

            // Send POST request to Flask
            var response = await _httpClient.PostAsync(flaskUrl, content);

            // Read the response from Flask
            var result = await response.Content.ReadAsStringAsync();

            // Return it back as application/json to frontend
            return Content(result, "application/json");
        }
    }
}
