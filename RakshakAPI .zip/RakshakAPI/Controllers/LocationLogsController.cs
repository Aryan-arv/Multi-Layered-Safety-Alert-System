﻿

//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using RakshakAPI.Data;
//using RakshakAPI.Models;
//using System.Security.Claims;
//using System.Linq;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class LocationLogsController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public LocationLogsController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // ✅ POST: api/LocationLogs → Logs location with JWT-based username
//        [HttpPost]
//        [Authorize]
//        public IActionResult LogLocation([FromBody] LocationLog log)
//        {
//            if (!ModelState.IsValid)
//                return BadRequest(ModelState);

//            // ✅ Extract username from JWT token
//            var username = User.FindFirst(ClaimTypes.Name)?.Value;
//            if (string.IsNullOrEmpty(username))
//                return Unauthorized(new { message = "Username not found in token." });

//            log.Username = username;
//            _context.LocationLogs.Add(log);
//            _context.SaveChanges();

//            return Ok(new { message = "Location logged successfully!" });
//        }

//        // ✅ GET: api/LocationLogs → View all SOS logs (secured)
//        [HttpGet]
//        [Authorize]
//        public IActionResult GetAllLogs()
//        {
//            var logs = _context.LocationLogs
//                .OrderByDescending(l => l.Timestamp)
//                .Select(l => new
//                {
//                    l.Username,
//                    l.Latitude,
//                    l.Longitude,
//                    l.Message,
//                    l.Timestamp
//                })
//                .ToList();

//            return Ok(logs);
//        }
//    }
//}






//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using RakshakAPI.Data;
//using RakshakAPI.Models;
//using System.Security.Claims;
//using System.Linq;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class LocationLogsController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public LocationLogsController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // ✅ POST: api/LocationLogs → Logs location with JWT-based username
//        [HttpPost]
//        [Authorize]
//        public IActionResult LogLocation([FromBody] LocationLog log)
//        {
//            if (!ModelState.IsValid)
//                return BadRequest(ModelState);

//            var username = User.FindFirst(ClaimTypes.Name)?.Value;
//            if (string.IsNullOrEmpty(username))
//                return Unauthorized(new { message = "Username not found in token." });

//            log.Username = username;
//            _context.LocationLogs.Add(log);
//            _context.SaveChanges();

//            return Ok(new { message = "Location logged successfully!" });
//        }

//        // ✅ GET: api/LocationLogs → View all logs
//        [HttpGet]
//        [Authorize]
//        public IActionResult GetAllLogs()
//        {
//            var logs = _context.LocationLogs
//                .OrderByDescending(l => l.Timestamp)
//                .Select(l => new
//                {
//                    l.Username,
//                    l.Latitude,
//                    l.Longitude,
//                    l.Message,
//                    l.Timestamp
//                })
//                .ToList();

//            return Ok(logs);
//        }

// ✅ NEW: GET api/LocationLogs/filter?start=2025-05-01&end=2025-05-03
// ✅ GET: api/LocationLogs/filter?start=2025-05-01&end=2025-05-03
// ✅ GET: api/LocationLogs/filter?start=2025-05-01&end=2025-05-03
//[HttpGet("filter")]
//[Authorize]
//public IActionResult GetLogsByDateRange([FromQuery] DateTime start, [FromQuery] DateTime end)
//{
//    if (start > end)
//        return BadRequest("Start date must be before or equal to end date.");

//    var filteredLogs = _context.LocationLogs
//        .Where(log => log.Timestamp.Date >= start.Date && log.Timestamp.Date <= end.Date)
//        .OrderByDescending(log => log.Timestamp)
//        .Select(log => new
//        {
//            log.Username,
//            log.Latitude,
//            log.Longitude,
//            log.Message,
//            log.Timestamp
//        })
//        .ToList();

//    return Ok(filteredLogs);
//}
// ✅ Add this at the end of LocationLogsController.cs
//        [HttpGet("filter")]
//        [Authorize]
//        public IActionResult GetLogsByDateRange([FromQuery] DateTime start, [FromQuery] DateTime end)
//        {
//            if (start > end)
//                return BadRequest("Start date must be before or equal to end date.");

//            var filteredLogs = _context.LocationLogs
//                .Where(log => log.Timestamp >= start && log.Timestamp <= end.AddDays(1)) // Include full end day
//                .OrderByDescending(log => log.Timestamp)
//                .Select(log => new
//                {
//                    log.Username,
//                    log.Latitude,
//                    log.Longitude,
//                    log.Message,
//                    log.Timestamp
//                })
//                .ToList();

//            return Ok(filteredLogs);
//        }


//    }
//}


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RakshakAPI.Data;
using RakshakAPI.Models;
using System.Security.Claims;
using System.Linq;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class LocationLogsController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public LocationLogsController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // ✅ POST: api/LocationLogs → Logs location with JWT-based username
//        [HttpPost]
//        [Authorize]
//        public IActionResult LogLocation([FromBody] LocationLog log)
//        {
//            if (!ModelState.IsValid)
//                return BadRequest(ModelState);

//            var username = User.FindFirst(ClaimTypes.Name)?.Value;
//            if (string.IsNullOrEmpty(username))
//                return Unauthorized(new { message = "Username not found in token." });

//            log.Username = username;
//            _context.LocationLogs.Add(log);
//            _context.SaveChanges();

//            return Ok(new { message = "Location logged successfully!" });
//        }

//        // ✅ GET: api/LocationLogs → Get all logs (used in admin panel)
//        [HttpGet]
//        [Authorize]
//        public IActionResult GetAllLogs()
//        {
//            var logs = _context.LocationLogs
//                .OrderByDescending(l => l.Timestamp)
//                .Select(l => new
//                {
//                    l.Username,
//                    l.Latitude,
//                    l.Longitude,
//                    l.Message,
//                    l.Timestamp
//                })
//                .ToList();

//            return Ok(logs);
//        }
//    }
//}


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RakshakAPI.Data;
using RakshakAPI.Models;
using System.Security.Claims;
using System.Linq;

namespace RakshakAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationLogsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public LocationLogsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ POST: api/LocationLogs → Logs location with JWT-based username
        [HttpPost]
        [Authorize]
        public IActionResult LogLocation([FromBody] LocationLog log)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var username = User.FindFirst(ClaimTypes.Name)?.Value;
            if (string.IsNullOrEmpty(username))
                return Unauthorized(new { message = "Username not found in token." });

            log.Username = username;
            _context.LocationLogs.Add(log);
            _context.SaveChanges();

            return Ok(new { message = "Location logged successfully!" });
        }

        // ✅ GET: api/LocationLogs → Get all logs (no [Authorize] for Admin UI)
        [HttpGet]
        public IActionResult GetAllLogs()
        {
            var logs = _context.LocationLogs
                .OrderByDescending(l => l.Timestamp)
                .Select(l => new
                {
                    l.Username,
                    l.Latitude,
                    l.Longitude,
                    l.Message,
                    l.Timestamp
                }).ToList();

            return Ok(logs);
        }
    }
}
