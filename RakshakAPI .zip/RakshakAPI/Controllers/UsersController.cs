﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class UsersController : ControllerBase
//    {
//    }
//}
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RakshakAPI.Data;
using RakshakAPI.Models;

namespace RakshakAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public UsersController(ApplicationDbContext context)
        {
            _context = context;
        }

        //[HttpPut("update-profile")]
        //[Authorize]
        //public async Task<IActionResult> UpdateProfile([FromBody] User updatedUser)
        //{
        //    if (updatedUser == null || updatedUser.Id == 0)
        //        return BadRequest("Invalid user data.");

        //    var existingUser = await _context.Users.FindAsync(updatedUser.Id);
        //    if (existingUser == null)
        //        return NotFound("User not found.");

        //    // Update all fields
        //    existingUser.Gender = updatedUser.Gender;
        //    existingUser.DateOfBirth = updatedUser.DateOfBirth;
        //    existingUser.AddressLine1 = updatedUser.AddressLine1;
        //    existingUser.AddressLine2 = updatedUser.AddressLine2;
        //    existingUser.PinCode = updatedUser.PinCode;
        //    existingUser.ParentName = updatedUser.ParentName;
        //    existingUser.ParentContact = updatedUser.ParentContact;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //        return Ok("Profile updated successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"Error saving profile: {ex.Message}");
        //    }
        //}
        //        [HttpPut("update-profile")]
        //        [Authorize]
        //        public async Task<IActionResult> UpdateProfile([FromBody] UserProfileDTO updatedUser)
        //        {
        //            if (updatedUser == null || updatedUser.Id == 0)
        //                return BadRequest("Invalid user data.");

        //            var existingUser = await _context.Users.FindAsync(updatedUser.Id);
        //            if (existingUser == null)
        //                return NotFound("User not found.");

        //            existingUser.Gender = updatedUser.Gender;
        //            existingUser.DateOfBirth = updatedUser.DateOfBirth;
        //            existingUser.AddressLine1 = updatedUser.AddressLine1;
        //            existingUser.AddressLine2 = updatedUser.AddressLine2;
        //            existingUser.PinCode = updatedUser.PinCode;
        //            existingUser.ParentName = updatedUser.ParentName;
        //            existingUser.ParentContact = updatedUser.ParentContact;

        //            try
        //            {
        //                await _context.SaveChangesAsync();
        //                return Ok("Profile updated successfully.");
        //            }
        //            catch (Exception ex)
        //            {
        //                return StatusCode(500, $"Error saving profile: {ex.Message}");
        //            }
        //        }
        //        [HttpGet("get-profile")]
        //        [Authorize]
        //        public IActionResult GetProfile()
        //        {
        //            var username = User.Identity?.Name;
        //            var user = _context.Users.FirstOrDefault(u => u.Username == username);
        //            if (user == null) return NotFound();

        //            return Ok(new
        //            {
        //                id = user.Id,
        //                gender = user.Gender,
        //                dateOfBirth = user.DateOfBirth,
        //                addressLine1 = user.AddressLine1,
        //                addressLine2 = user.AddressLine2,
        //                pinCode = user.PinCode,
        //                parentName = user.ParentName,
        //                parentContact = user.ParentContact
        //            });
        //        }

        //    }
        //}

        [HttpPut("update-profile")]
        [Authorize]
        public async Task<IActionResult> UpdateProfile([FromBody] UserProfileDTO updatedUser)
        {
           

            if (updatedUser == null || updatedUser.Id == 0)
                return BadRequest("Invalid user data.");

            var existingUser = await _context.Users.FindAsync(updatedUser.Id);
            if (existingUser == null)
                return NotFound("User not found.");


            // Update profile fields
            existingUser.Gender = updatedUser.Gender;
            existingUser.DateOfBirth = updatedUser.DateOfBirth;
            existingUser.AddressLine1 = updatedUser.AddressLine1;
            existingUser.AddressLine2 = updatedUser.AddressLine2;
            existingUser.PinCode = updatedUser.PinCode;
            existingUser.ParentName = updatedUser.ParentName;
            existingUser.ParentContact = updatedUser.ParentContact;

            try
            {
                await _context.SaveChangesAsync();
                return Ok("Profile updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error saving profile: {ex.Message}");
            }
        }

        [HttpGet("get-profile")]
        [Authorize]
        public IActionResult GetProfile()
        {
            var username = User.Identity?.Name;
            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user == null) return NotFound();

            return Ok(new
            {
                id = user.Id,
                gender = user.Gender,
                dateOfBirth = user.DateOfBirth,
                addressLine1 = user.AddressLine1,
                addressLine2 = user.AddressLine2,
                pinCode = user.PinCode,
                parentName = user.ParentName,
                parentContact = user.ParentContact
            });
        }
    }
}