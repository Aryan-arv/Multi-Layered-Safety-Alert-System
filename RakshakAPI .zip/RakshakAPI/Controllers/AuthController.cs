﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AuthController : ControllerBase
//    {
//    }
//}


//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.Tokens;
//using RakshakAPI.Data;
//using RakshakAPI.Models;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;
//using Microsoft.Extensions.Logging;


//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AuthController : ControllerBase
//    {
//        private readonly IConfiguration _configuration;
//        private readonly ApplicationDbContext _context;
//        private readonly ILogger<AuthController> _logger;


//public AuthController(IConfiguration configuration, ApplicationDbContext context)
//{
//    _configuration = configuration;
//    _context = context;
//}
//public AuthController(IConfiguration configuration, ApplicationDbContext context, ILogger<AuthController> logger)
//{
//    _configuration = configuration;
//    _context = context;
//    _logger = logger;
//}



//[HttpPost("register")]
//public IActionResult Register(User user)
//{
//    // You should hash password here before storing (for now, we keep it simple)
//    _context.Users.Add(user);
//    _context.SaveChanges();
//    return Ok(new { message = "User registered successfully." });
//}

//[HttpPost("login")]
//public IActionResult Login(User user)
//{
//    var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);
//    if (existingUser == null)
//        return Unauthorized(new { message = "Invalid credentials." });

//    var token = GenerateJwtToken(user.Username);
//    return Ok(new { token });
//}
//        [HttpPost("login")]
//        public IActionResult Login(User user)
//        {
//            _logger.LogInformation("Attempting login for username: " + user.Username);

//            var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username);

//            if (existingUser == null)
//            {
//                _logger.LogWarning("Login failed: user not found - " + user.Username);
//                return Unauthorized(new { message = "Invalid credentials." });
//            }

//            if (existingUser.Password != user.Password)
//            {
//                _logger.LogWarning("Incorrect password for user: " + user.Username);
//                return Unauthorized(new { message = "Invalid credentials." });
//            }

//            _logger.LogInformation("Login successful for user: " + user.Username);

//            var token = GenerateJwtToken(user.Username);
//            return Ok(new { token });
//        }



//        private string GenerateJwtToken(string username)
//        {
//            var jwtSettings = _configuration.GetSection("JwtSettings");
//            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]));

//            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

//            var claims = new[]
//            {
//                new Claim(JwtRegisteredClaimNames.Sub, username),
//                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
//            };

//            var token = new JwtSecurityToken(
//                issuer: jwtSettings["Issuer"],
//                audience: jwtSettings["Audience"],
//                claims: claims,
//                expires: DateTime.UtcNow.AddHours(2),
//                signingCredentials: creds
//            );

//            return new JwtSecurityTokenHandler().WriteToken(token);
//        }
//    }
//}




//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.Tokens;
//using RakshakAPI.Data;
//using RakshakAPI.Models;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;
//using Microsoft.Extensions.Logging;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AuthController : ControllerBase
//    {
//        private readonly IConfiguration _configuration;
//        private readonly ApplicationDbContext _context;
//        private readonly ILogger<AuthController> _logger;

//        public AuthController(IConfiguration configuration, ApplicationDbContext context, ILogger<AuthController> logger)
//        {
//            _configuration = configuration;
//            _context = context;
//            _logger = logger;
//        }

//        [HttpPost("register")]
//        public IActionResult Register(User user)
//        {
//            // ⚠️ In production, password must be hashed.
//            _context.Users.Add(user);
//            _context.SaveChanges();
//            return Ok(new { message = "User registered successfully." });
//        }

//        [HttpPost("login")]
//        public IActionResult Login(User user)
//        {
//            _logger.LogInformation("Attempting login for username: " + user.Username);

//            var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username);

//            if (existingUser == null)
//            {
//                _logger.LogWarning("Login failed: user not found - " + user.Username);
//                return Unauthorized(new { message = "Invalid credentials." });
//            }

//            if (existingUser.Password != user.Password)
//            {
//                _logger.LogWarning("Incorrect password for user: " + user.Username);
//                return Unauthorized(new { message = "Invalid credentials." });
//            }

//            _logger.LogInformation("Login successful for user: " + user.Username);

//            var token = GenerateJwtToken(user.Username);
//            return Ok(new { token });
//        }

//        private string GenerateJwtToken(string username)
//        {
//            var jwtSettings = _configuration.GetSection("JwtSettings");
//            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]));
//            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

//            // ✅ Added ClaimTypes.Name here
//            var claims = new[]
//            {
//                new Claim(JwtRegisteredClaimNames.Sub, username),
//                new Claim(ClaimTypes.Name, username), // 🔥 This enables secure extraction in protected controllers
//                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
//            };

//            var token = new JwtSecurityToken(
//                issuer: jwtSettings["Issuer"],
//                audience: jwtSettings["Audience"],
//                claims: claims,
//                expires: DateTime.UtcNow.AddHours(2),
//                signingCredentials: creds
//            );

//            return new JwtSecurityTokenHandler().WriteToken(token);
//        }
//    }
//}



//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.Tokens;
//using RakshakAPI.Data;
//using RakshakAPI.Models;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;
//using Microsoft.Extensions.Logging;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AuthController : ControllerBase
//    {
//        private readonly IConfiguration _configuration;
//        private readonly ApplicationDbContext _context;
//        private readonly ILogger<AuthController> _logger;

//        public AuthController(IConfiguration configuration, ApplicationDbContext context, ILogger<AuthController> logger)
//        {
//            _configuration = configuration;
//            _context = context;
//            _logger = logger;
//        }

//        [HttpPost("register")]
//        public IActionResult Register(User user)
//        {
//            _context.Users.Add(user);
//            _context.SaveChanges();
//            return Ok(new { message = "User registered successfully." });
//        }

//        [HttpPost("login")]
//        public IActionResult Login(User user)
//        {
//            _logger.LogInformation("Attempting login for username: " + user.Username);

//            var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username);
//            if (existingUser == null || existingUser.Password != user.Password)
//            {
//                _logger.LogWarning("Login failed for user: " + user.Username);
//                return Unauthorized(new { message = "Invalid credentials." });
//            }

//            var token = GenerateJwtToken(existingUser.Username);
//            return Ok(new { token });
//        }

//private string GenerateJwtToken(string username)
//{
//    var jwtSettings = _configuration.GetSection("JwtSettings");
//    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]));
//    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

//    var claims = new[]
//    {
//        new Claim(JwtRegisteredClaimNames.Sub, username),
//        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
//        new Claim(ClaimTypes.Name, username) // ✅ needed for backend to extract
//    };

//    var token = new JwtSecurityToken(
//        issuer: jwtSettings["Issuer"],
//        audience: jwtSettings["Audience"],
//        claims: claims,
//        expires: DateTime.UtcNow.AddHours(2),
//        signingCredentials: creds
//    );

//    return new JwtSecurityTokenHandler().WriteToken(token);
//}
//        private string GenerateJwtToken(string username)
//        {
//            var jwtSettings = _configuration.GetSection("JwtSettings");
//            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]));
//            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

//            var claims = new[]
//            {
//        new Claim(JwtRegisteredClaimNames.Sub, username),
//        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
//        new Claim(ClaimTypes.Name, username),
//        new Claim("iss", jwtSettings["Issuer"]),
//        new Claim("aud", jwtSettings["Audience"])
//    };

//            var token = new JwtSecurityToken(
//                issuer: jwtSettings["Issuer"],
//                audience: jwtSettings["Audience"],
//                claims: claims,
//                expires: DateTime.UtcNow.AddMinutes(Convert.ToDouble(jwtSettings["ExpiryMinutes"] ?? "60")),
//                signingCredentials: creds
//            );

//            return new JwtSecurityTokenHandler().WriteToken(token);
//        }

//    }
//}



using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RakshakAPI.Data;
using RakshakAPI.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Logging;

namespace RakshakAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuthController> _logger;

        public AuthController(IConfiguration configuration, ApplicationDbContext context, ILogger<AuthController> logger)
        {
            _configuration = configuration;
            _context = context;
            _logger = logger;
        }

        [HttpPost("register")]
        public IActionResult Register(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok(new { message = "User registered successfully." });
        }

        [HttpPost("login")]
        public IActionResult Login(User user)
        {
            _logger.LogInformation("Attempting login for username: " + user.Username);

            var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username);
            if (existingUser == null || existingUser.Password != user.Password)
            {
                _logger.LogWarning("Login failed for user: " + user.Username);
                return Unauthorized(new { message = "Invalid credentials." });
            }

            var token = GenerateJwtToken(existingUser.Username);
            return Ok(new { token });
        }

        private string GenerateJwtToken(string username)
        {
            var jwtSettings = _configuration.GetSection("JwtSettings");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Name, username),
                new Claim("iss", jwtSettings["Issuer"]),
                new Claim("aud", jwtSettings["Audience"])
            };

            var token = new JwtSecurityToken(
                issuer: jwtSettings["Issuer"],
                audience: jwtSettings["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(Convert.ToDouble(jwtSettings["ExpiryMinutes"] ?? "60")),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
