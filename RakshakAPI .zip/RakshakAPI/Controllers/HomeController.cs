﻿using Microsoft.AspNetCore.Mvc;

namespace RakshakAPI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
