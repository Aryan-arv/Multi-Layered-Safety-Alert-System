﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace RakshakAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class CrimeReportsController : ControllerBase
//    {
//    }
//}



using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RakshakAPI.Data;
using RakshakAPI.Models;
using AutoMapper;



namespace RakshakAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CrimeReportsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CrimeReportsController> _logger;
        private readonly IMapper _mapper;


        //public CrimeReportsController(ApplicationDbContext context, ILogger<CrimeReportsController> logger)
        //{
        //    _context = context;
        //    _logger = logger;
        //}

        public CrimeReportsController(ApplicationDbContext context, ILogger<CrimeReportsController> logger, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }



        // GET: ap
        //
        // i/CrimeReports
        [HttpGet]
        //public async Task<ActionResult<IEnumerable<CrimeReport>>> GetCrimeReports()            for all 25000 data 
        //{
        //    return await _context.CrimeReports.ToListAsync();
        //}
        //public async Task<ActionResult<IEnumerable<CrimeReport>>> GetCrimeReports()
        //{
        //    return await _context.CrimeReports
        //                         .Take(10) // ✅ Limit to 10 records
        //                         .ToListAsync();
        //}

        public async Task<ActionResult<IEnumerable<CrimeReportDTO>>> GetCrimeReports()
        {
            var crimeReports = await _context.CrimeReports.Take(10).ToListAsync();
            var crimeReportDtos = _mapper.Map<List<CrimeReportDTO>>(crimeReports);
            return Ok(crimeReportDtos);
        }




        // GET: api/CrimeReports/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CrimeReport>> GetCrimeReport(int id)
        {
            var crimeReport = await _context.CrimeReports.FindAsync(id);

            if (crimeReport == null)
            {
                _logger.LogWarning("CrimeReport with ID {Id} not found.", id);
                return NotFound();
            }

            _logger.LogInformation("CrimeReport with ID {Id} retrieved successfully.", id);
            return crimeReport;
        }

        // last get method ke baad for get endpoint 
        // GET: api/CrimeReports/region/{region}
        [HttpGet("region/{region}")]
        public async Task<ActionResult<IEnumerable<CrimeReport>>> GetByRegion(string region)
        {
            return await _context.CrimeReports
                .Where(r => r.Region.ToLower() == region.ToLower())
                .ToListAsync();
        }

        // GET: api/CrimeReports/area/{area}
        [HttpGet("area/{area}")]
        public async Task<ActionResult<IEnumerable<CrimeReport>>> GetByArea(string area)
        {
            return await _context.CrimeReports
                .Where(r => r.Area.ToLower() == area.ToLower())
                .ToListAsync();
        }

        // GET: api/CrimeReports/crimetype/{type}
        [HttpGet("crimetype/{type}")]
        public async Task<ActionResult<IEnumerable<CrimeReport>>> GetByCrimeType(string type)
        {
            return await _context.CrimeReports
                .Where(r => r.CrimeType.ToLower() == type.ToLower())
                .ToListAsync();
        }





        // POST: api/CrimeReports
        //[HttpPost]
        //public async Task<ActionResult<CrimeReport>> PostCrimeReport(CrimeReport crimeReport)
        //{
        //    _context.CrimeReports.Add(crimeReport);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction(nameof(GetCrimeReport), new { id = crimeReport.IncidentId }, crimeReport);
        //}

        //// PUT: api/CrimeReports/5
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutCrimeReport(int id, CrimeReport crimeReport)
        //{
        //    if (id != crimeReport.IncidentId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(crimeReport).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!CrimeReportExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}



        //[HttpPost]
        //public async Task<ActionResult<CrimeReport>> PostCrimeReport(CrimeReport crimeReport)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    _context.CrimeReports.Add(crimeReport);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction(nameof(GetCrimeReport), new { id = crimeReport.IncidentId }, crimeReport);
        //}
        [HttpPost]
        //public async Task<ActionResult<CrimeReportDTO>> CreateCrimeReport(CrimeReportDTO crimeReportDto)
        //{
        //    var crimeReport = _mapper.Map<CrimeReport>(crimeReportDto);
        //    _context.CrimeReports.Add(crimeReport);
        //    await _context.SaveChangesAsync();

        //    var createdCrimeReportDto = _mapper.Map<CrimeReportDTO>(crimeReport);
        //    return CreatedAtAction(nameof(GetCrimeReport), new { id = crimeReport.IncidentId }, createdCrimeReportDto);
        //}

        public async Task<ActionResult<CrimeReportDTO>> CreateCrimeReport(CrimeReportDTO crimeReportDto)
        {
            var crimeReport = _mapper.Map<CrimeReport>(crimeReportDto);
            _context.CrimeReports.Add(crimeReport);
            await _context.SaveChangesAsync();

            var createdDto = _mapper.Map<CrimeReportDTO>(crimeReport);
            return CreatedAtAction(nameof(GetCrimeReport), new { id = crimeReport.IncidentId }, createdDto);
        }

        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutCrimeReport(int id, CrimeReport crimeReport)
        //{
        //    if (id != crimeReport.IncidentId)
        //    {
        //        return BadRequest("Incident ID mismatch");
        //    }

        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    _context.Entry(crimeReport).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!_context.CrimeReports.Any(e => e.IncidentId == id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> UpdateCrimeReport(int id, CrimeReportDTO crimeReportDto)
        //{
        //    if (id != crimeReportDto.IncidentId)
        //    {
        //        return BadRequest("ID mismatch between route and body.");
        //    }

        //    var existingReport = await _context.CrimeReports.FindAsync(id);
        //    if (existingReport == null)
        //    {
        //        return NotFound($"No crime report found with ID {id}");
        //    }

        //    _mapper.Map(crimeReportDto, existingReport);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCrimeReport(int id, CrimeReportDTO crimeReportDto)
        {
            if (id <= 0)
                return BadRequest(new { message = "Invalid ID supplied" });

            var existingReport = await _context.CrimeReports.FindAsync(id);
            if (existingReport == null)
                return NotFound(new { message = $"CrimeReport with ID {id} not found." });

            _mapper.Map(crimeReportDto, existingReport);
            await _context.SaveChangesAsync();

            return NoContent();
        }


        // Helper method
        private bool CrimeReportExists(int id)
        {
            return _context.CrimeReports.Any(e => e.IncidentId == id);
        }

        // DELETE: api/CrimeReports/5
        [HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteCrimeReport(int id)
        //{
        //    var crimeReport = await _context.CrimeReports.FindAsync(id);
        //    if (crimeReport == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.CrimeReports.Remove(crimeReport);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}
        public async Task<IActionResult> DeleteCrimeReport(int id)
        {
            var crimeReport = await _context.CrimeReports.FindAsync(id);
            if (crimeReport == null)
            {
                _logger.LogWarning("Attempted to delete non-existent CrimeReport with ID: {Id}", id);
                return NotFound(new { message = $"CrimeReport with ID {id} not found." });
            }

            _context.CrimeReports.Remove(crimeReport);
            await _context.SaveChangesAsync();

            _logger.LogInformation("CrimeReport with ID {Id} deleted successfully.", id);
            return Ok(new { message = $"CrimeReport with ID {id} deleted successfully." });
        }



    }
}
