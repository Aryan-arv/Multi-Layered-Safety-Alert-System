﻿//namespace RakshakAPI.Profiles
//{
//    public class MappingProfile
//    {
//    }
//}


using AutoMapper;
using RakshakAPI.Models;

namespace RakshakAPI.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CrimeReport, CrimeReportDTO>().ReverseMap();
        }
    }
}
